'''from domain.Huesped import Customer
from application.CustomerService import CustomerService
from data.CustomerRepository import CustomerRepository
from data.ConexionMySQL import Conexion'''
from view.Menu import Menu
        
        
# Ejecuta el menú
menu = Menu()
menu.app()
